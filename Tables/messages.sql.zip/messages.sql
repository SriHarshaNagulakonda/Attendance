-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:33 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `fromm` varchar(15) NOT NULL,
  `too` varchar(15) NOT NULL,
  `msg` varchar(200) NOT NULL,
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`fromm`,`too`,`msg`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`fromm`, `too`, `msg`, `time`) VALUES
('17341A0501', '17341A0502', 'ashok is the best', 'Sun Apr 07 03:50:33 IST 2019'),
('17341A0501', '17341A0502', 'frfdgedfyhtht', 'Tue Apr 09 11:58:35 IST 2019'),
('17341A0501', '17341A0502', 'hellloooooo', 'Sat Apr 06 20:10:26 IST 2019'),
('17341A0501', '17341A0502', 'hello world', 'Sat Apr 06 20:25:18 IST 2019'),
('17341A0501', '17341A0502', 'hsdf\r\n', 'Mon Apr 08 18:54:23 IST 2019'),
('17341A0501', '17341A0503', 'hellloooooo', 'Sat Apr 06 20:10:26 IST 2019'),
('17341A0501', '17341A0504', 'hello how are you', 'Sat Apr 06 20:26:50 IST 2019'),
('17341A0501', '17341A0505', 'hello gud night', 'Sat Apr 06 20:45:30 IST 2019'),
('17341A0502', '17341A0501', 'hello gud nyt', 'Mon Apr 08 18:58:07 IST 2019'),
('17341A0503', '17341A0505', 'hai i am 503', 'Sun Apr 07 09:40:32 IST 2019'),
('17341A0507', '17341A0506', 'hello\r\n', 'Mon Apr 15 18:33:02 IST 2019'),
('17341A0533', '17341A0502', 'hello im new student', 'Tue Apr 09 10:11:47 IST 2019'),
('17341A0537', '17341A0501', 'hii hello', 'Wed Apr 10 15:56:26 IST 2019');
