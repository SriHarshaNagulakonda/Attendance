-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:32 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_name`
--

CREATE TABLE IF NOT EXISTS `course_name` (
  `c_id` varchar(10) NOT NULL,
  `sdate` date NOT NULL,
  `edate` date NOT NULL,
  `cname` varchar(30) NOT NULL,
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `cname` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_name`
--

INSERT INTO `course_name` (`c_id`, `sdate`, `edate`, `cname`) VALUES
('1', '2019-01-07', '2019-03-09', 'DS'),
('2', '2019-02-04', '2019-04-13', 'DBMS'),
('3', '2019-02-04', '2019-04-13', 'JAVA'),
('4', '2019-06-10', '2019-11-22', 'DL'),
('5', '2019-06-10', '2019-11-22', 'ML'),
('6', '2019-06-10', '2019-11-22', 'AI'),
('7', '2019-06-10', '2019-11-22', 'DAA'),
('8', '2019-06-10', '2019-11-22', 'AC'),
('9', '2019-04-19', '2019-08-15', 'ashok');
