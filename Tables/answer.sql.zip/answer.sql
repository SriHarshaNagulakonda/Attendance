-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:31 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE IF NOT EXISTS `answer` (
  `a_id` varchar(10) NOT NULL,
  `c_id` varchar(30) NOT NULL,
  `s_id` varchar(10) NOT NULL,
  `answer` varchar(100) NOT NULL,
  PRIMARY KEY (`a_id`,`c_id`,`s_id`),
  KEY `c_id` (`c_id`),
  KEY `s_id` (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`a_id`, `c_id`, `s_id`, `answer`) VALUES
('1', '1', '17341A0501', 'Data Structures'),
('1', '1', '17341A0506', 'Data Science'),
('2', '1', '17341A0501', 'contact Mr.ashok phd'),
('2', '1', '17341A0502', 'hrello'),
('3', '2', '17341A0507', 'second normal form'),
('4', '1', '17341A0501', 'hfheshntsdfsdf');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`a_id`) REFERENCES `question` (`a_id`),
  ADD CONSTRAINT `answer_ibfk_2` FOREIGN KEY (`c_id`) REFERENCES `courses` (`c_id`),
  ADD CONSTRAINT `answer_ibfk_3` FOREIGN KEY (`s_id`) REFERENCES `courses` (`s_id`);
