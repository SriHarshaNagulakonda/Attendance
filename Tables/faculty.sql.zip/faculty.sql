-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:32 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `name` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `btech` varchar(30) NOT NULL,
  `mtech` varchar(30) NOT NULL,
  `phd` varchar(30) NOT NULL,
  `experiance` int(11) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `f_id` varchar(30) NOT NULL,
  `pass` int(11) NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`name`, `gender`, `qualification`, `btech`, `mtech`, `phd`, `experiance`, `phone`, `mail`, `f_id`, `pass`) VALUES
('ASHOK', 'Male', 'Phd', 'GMRIT', 'IIT', 'IIT', 15, 'ashokphd@gmail.com', '1234567890', '101', 101),
('RAKESH', 'Male', 'MTECH', 'GMRIT', 'NIT', 'IIT', 10, 'RAKESH@GMAIL.COM', '1234567899', '102', 102),
('ashok', 'Male', 'Phd', 'Gmrit', 'IIT B ombay', 'Stanford University', 10, 'ashokgunturu135@gmail.com', '9182734254', '103', 103),
('harsha', 'Male', 'Phd', 'Gmrit', 'IIT B ombay', 'Stanford University', 10, 'harsha@gmail.com', '9876543210', '104', 104),
('anil', 'Male', 'phd', 'Gmrit', 'IIT B ombay', 'Stanford University', 10, 'abcd@gmail.com', '2233445566', '105', 105),
('Hemanth', 'Male', 'Phd', 'IIT', 'Standford University', 'OXFORD University', 35, 'hemanth@gmail.com', '1234123456', '106', 106),
('jagan', 'Male', 'm tech', 'AU', 'NIT', 'NIT', 20, 'njhgvbnm2@gmail.com', '1234567890', '107', 107),
('ashok', 'Male', 'Phd', 'Gmrit', 'IIT B ombay', 'Stanford University', 10, 'asdfghj@gmail.com', '1232134565', '108', 108),
('Sagar', 'Male', 'Phd', 'IIT', 'Standford University', 'OXFORD University', 35, 'sagar@gmail.com', '9999999999', '109', 109);
