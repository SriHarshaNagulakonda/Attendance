-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:34 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `subjectalloc`
--

CREATE TABLE IF NOT EXISTS `subjectalloc` (
  `c_id` varchar(30) NOT NULL,
  `f_id` varchar(30) NOT NULL,
  PRIMARY KEY (`c_id`,`f_id`),
  KEY `f_id` (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectalloc`
--

INSERT INTO `subjectalloc` (`c_id`, `f_id`) VALUES
('1', '101'),
('4', '101'),
('5', '101'),
('1', '102'),
('2', '102'),
('3', '102'),
('1', '103'),
('2', '103'),
('3', '103'),
('4', '104'),
('6', '104'),
('7', '104'),
('3', '105'),
('4', '105'),
('5', '105'),
('2', '106'),
('5', '106'),
('6', '106'),
('6', '107'),
('7', '107'),
('8', '107'),
('1', '108'),
('3', '108'),
('5', '108'),
('1', '109'),
('3', '109'),
('5', '109');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `subjectalloc`
--
ALTER TABLE `subjectalloc`
  ADD CONSTRAINT `subjectalloc_ibfk_2` FOREIGN KEY (`f_id`) REFERENCES `faculty` (`f_id`),
  ADD CONSTRAINT `subjectalloc_ibfk_3` FOREIGN KEY (`c_id`) REFERENCES `course_name` (`c_id`);
