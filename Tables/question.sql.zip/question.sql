-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 08:33 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `a_id` varchar(10) NOT NULL,
  `f_id` varchar(30) NOT NULL,
  `c_id` varchar(30) NOT NULL,
  `question` varchar(100) NOT NULL,
  PRIMARY KEY (`a_id`,`f_id`,`c_id`),
  KEY `f_id` (`f_id`),
  KEY `c_id` (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`a_id`, `f_id`, `c_id`, `question`) VALUES
('1', '101', '1', 'what is ds'),
('1', '101', '2', 'what is a Database'),
('1', '101', '4', 'what is DL?'),
('1', '102', '1', 'What is DS?'),
('1', '102', '2', 'what is SQL'),
('2', '101', '1', 'what is stack'),
('2', '101', '4', 'what is a recurrent neural network?'),
('2', '102', '2', 'What is Normalization'),
('3', '101', '1', 'Expalin Linked List'),
('3', '101', '4', 'What is NN?'),
('3', '102', '2', 'What is 2NF?'),
('4', '101', '1', 'Define AVL and BST.'),
('5', '101', '1', 'Define B and B+ trees.'),
('6', '101', '1', 'explain DS'),
('7', '101', '1', 'what is B tree?'),
('8', '101', '1', 'addsafsfdf');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_3` FOREIGN KEY (`f_id`) REFERENCES `courses` (`f_id`),
  ADD CONSTRAINT `question_ibfk_4` FOREIGN KEY (`c_id`) REFERENCES `courses` (`c_id`);
